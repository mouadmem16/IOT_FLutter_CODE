import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:iot_heartbeats/screens/home_page.dart';

class LocalNotification extends StatefulWidget {
  @override
  _LocalNotificationState createState() => _LocalNotificationState();
}

class _LocalNotificationState extends State<LocalNotification> {
  FlutterLocalNotificationsPlugin notification =
      FlutterLocalNotificationsPlugin();

  @override
  void initState() {
    var initSettAndroid = AndroidInitializationSettings('heart');
    var initSettIOS = IOSInitializationSettings(
        onDidReceiveLocalNotification: (id, title, body, payload) =>
            onSelectNotification(payload));
    var initializationSettings =
        InitializationSettings(initSettAndroid, initSettIOS);
    notification.initialize(initializationSettings,
        onSelectNotification: onSelectNotification);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: RaisedButton(
        onPressed: () => showOnGoingNotification(
            notification, "title", "body bodybody bodybody body"),
        child: Text("PRES ME"),
      ),
    );
  }

  Future onSelectNotification(String payload) async => await Navigator.push(
      context, MaterialPageRoute(builder: (context) => HomePage()));

  showOnGoingNotification(
      FlutterLocalNotificationsPlugin notification, String title, String body,
      {int id = 0}) {
    final AndroidChanneltype = AndroidNotificationDetails(
        "channel ID", "Channel Name", "Channel Description",
        importance: Importance.Max, priority: Priority.High, autoCancel: false);

    final IOSChanneltype = IOSNotificationDetails();

    return notification.show(id, title, body,
        NotificationDetails(AndroidChanneltype, IOSChanneltype));
  }
}
